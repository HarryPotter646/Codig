import type React from "react"
import "@/app/globals.css"
import type { Metadata } from "next"
import { Inter, JetBrains_Mono } from 'next/font/google'

// Load Inter font for general text
const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

// Load JetBrains Mono for code-like text
const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-jetbrains",
})

export const metadata: Metadata = {
  title: "Codig - Code Digital Solutions",
  description: "Innovation, security and digital excellence.",
  other: {
    "google": "notranslate",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`scroll-smooth ${inter.variable} ${jetbrainsMono.variable}`}>
      <body translate="no" className="font-sans">{children}</body>
    </html>
  )
}