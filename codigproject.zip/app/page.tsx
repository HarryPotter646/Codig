import FlowingTextBackground from "@/components/flowing-text-background"
import HeroSection from "@/components/hero-section"
import Navbar from "@/components/navbar"
import ServicesSection from "@/components/services-section"
import AboutSection from "@/components/about-section"
import ProjectsSection from "@/components/projects-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import { LanguageProvider } from "@/components/language-provider"

export default function Home() {
  return (
    <LanguageProvider defaultLanguage="de">
      <div className="relative min-h-screen overflow-hidden">
        <FlowingTextBackground />
        <div className="relative z-10">
          <Navbar />
          <main>
            <HeroSection />
            <AboutSection />
            <ServicesSection />
            <ProjectsSection />
            <ContactSection />
          </main>
          <Footer />
        </div>
      </div>
    </LanguageProvider>
  )
}