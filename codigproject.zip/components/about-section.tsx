"use client"

import { useLanguage } from "./language-provider"
import AnimationWrapper from "./animation-wrapper"

export default function AboutSection() {
  const { t, getAboutContent, getStats } = useLanguage()
  const content = getAboutContent()
  const stats = getStats()

  return (
    <section className="py-20 bg-[#121212]" id="about">
      <div className="container mx-auto px-4">
        <AnimationWrapper>
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white">{t("about", "title")}</h2>
            <div className="w-20 h-1 bg-green-600 mx-auto mt-4"></div>
            <p className="text-gray-300 mt-4 max-w-2xl mx-auto">{t("about", "subtitle")}</p>
          </div>
        </AnimationWrapper>

        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div className="md:w-1/2">
            <div className="space-y-6">
              {content.map((paragraph, index) => (
                <AnimationWrapper key={index} direction="right" delay={index * 0.1}>
                  <p className="text-gray-300">{paragraph}</p>
                </AnimationWrapper>
              ))}
            </div>
          </div>

          <div className="md:w-1/2">
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <AnimationWrapper key={index} direction="up" delay={index * 0.1}>
                  <div className="bg-[#1a1a1a] p-6 rounded-lg shadow-md text-center border border-gray-800">
                    <div className="text-3xl font-bold text-green-400 mb-2 font-code">{stat.value}</div>
                    <div className="text-gray-300">{stat.label}</div>
                  </div>
                </AnimationWrapper>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}