"use client"
import Navbar from "./navbar"

export default function NavbarWrapper() {
  return <Navbar />
}
