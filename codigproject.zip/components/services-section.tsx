"use client"

import { useLanguage } from "./language-provider"
import { Code, Smartphone, Server, Shield, Cloud, Lightbulb, Palette, Megaphone } from 'lucide-react'
import AnimationWrapper from "./animation-wrapper"

export default function ServicesSection() {
  const { t, getServiceItems } = useLanguage()
  const services = getServiceItems()

  const icons = [
    <Code key="web" size={32} className="text-green-400" />,
    <Smartphone key="app" size={32} className="text-green-400" />,
    <Server key="api" size={32} className="text-green-400" />,
    <Shield key="security" size={32} className="text-green-400" />,
    <Cloud key="cloud" size={32} className="text-green-400" />,
    <Lightbulb key="consulting" size={32} className="text-green-400" />,
    <Palette key="design" size={32} className="text-green-400" />,
    <Megaphone key="marketing" size={32} className="text-green-400" />,
  ]

  return (
    <section className="py-20 bg-[#191919]" id="services">
      <div className="container mx-auto px-4">
        <AnimationWrapper>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white">{t("services", "title")}</h2>
            <div className="w-20 h-1 bg-green-600 mx-auto mt-4"></div>
            <p className="text-gray-300 mt-4 max-w-2xl mx-auto">{t("services", "subtitle")}</p>
          </div>
        </AnimationWrapper>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <AnimationWrapper key={index} direction="up" delay={index * 0.1} threshold={0.2}>
              <div className="bg-[#1a1a1a] rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow border border-gray-800 group h-full">
                <div className="mb-4">{icons[index % icons.length]}</div>
                <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-green-400 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-300">{service.description}</p>
              </div>
            </AnimationWrapper>
          ))}
        </div>
      </div>
    </section>
  )
}