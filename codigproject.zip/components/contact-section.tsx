"use client"

import { useLanguage } from "./language-provider"
import ContactForm from "./contact-form"
import AnimationWrapper from "./animation-wrapper"

export default function ContactSection() {
  const { t } = useLanguage()

  return (
    <section className="py-20 bg-[#191919]" id="contact">
      <div className="container mx-auto px-4">
        <AnimationWrapper>
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white">{t("contact", "title")}</h2>
            <div className="w-20 h-1 bg-green-600 mx-auto mt-4"></div>
            <p className="text-gray-300 mt-4 max-w-2xl mx-auto">{t("contact", "subtitle")}</p>
          </div>
        </AnimationWrapper>

        <AnimationWrapper direction="up" delay={0.2}>
          <ContactForm />
        </AnimationWrapper>
      </div>
    </section>
  )
}