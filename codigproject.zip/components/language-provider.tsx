"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type Language = "de" | "en"

type ContentType = {
  [key in Language]: {
    navigation: {
      about: string
      services: string
      projects: string
      contact: string
    }
    hero: {
      title: string
      subtitle: string
      cta: string
    }
    about: {
      title: string
      subtitle: string
      content: string[]
      stats: Array<{
        value: string
        label: string
      }>
    }
    services: {
      title: string
      subtitle: string
      items: Array<{
        title: string
        description: string
      }>
    }
    projects: {
      title: string
      subtitle: string
      items: Array<{
        title: string
        description: string
        tags: string[]
        img: string
      }>
    }
    contact: {
      title: string
      subtitle: string
      name: string
      email: string
      message: string
      send: string
      success: string
      error: string
    }
    footer: {
      imprint: string
      imprintText: string
      copyright: string
    }
  }
}

const content: ContentType = {
  de: {
    navigation: {
      about: "Über uns",
      services: "Leistungen",
      projects: "Projekte",
      contact: "Kontakt",
    },
    hero: {
      title: "Sichern Sie Ihre digitale Zukunft",
      subtitle:
        "Fachwissen in den Bereichen Cybersicherheit, Web-/Mobile-Entwicklung und Beratung, um Ihr Unternehmen voranzubringen.",
      cta: "Mehr erfahren",
    },
    about: {
      title: "Über Codig",
      subtitle: "Wir sind Ihr Partner für digitale Lösungen",
      content: [
        "Codig ist ein innovatives Technologieunternehmen, das sich auf die Entwicklung maßgeschneiderter digitaler Lösungen spezialisiert hat.",
        "Unser Team aus erfahrenen Entwicklern, Designern und Beratern arbeitet eng mit Ihnen zusammen, um Ihre Vision in die Realität umzusetzen.",
        "Mit unserem Fachwissen in den Bereichen Webentwicklung, App-Entwicklung, IT-Sicherheit und Cloud-Lösungen bieten wir Ihnen einen umfassenden Service aus einer Hand.",
      ],
      stats: [
        {
          value: "50+",
          label: "Zufriedene Kunden",
        },
        {
          value: "100+",
          label: "Abgeschlossene Projekte",
        },
        {
          value: "5+",
          label: "Jahre Erfahrung",
        },
        {
          value: "24/7",
          label: "Support",
        },
      ],
    },
    services: {
      title: "Unsere Leistungen",
      subtitle: "Maßgeschneiderte Lösungen für Ihr Unternehmen",
      items: [
        {
          title: "Webentwicklung",
          description: "Moderne, responsive Websites und Webanwendungen mit den neuesten Technologien.",
        },
        {
          title: "App-Entwicklung",
          description: "Native und Cross-Platform-Apps für iOS und Android mit optimaler Performance.",
        },
        {
          title: "APIs & Schnittstellen",
          description: "Entwicklung und Integration von APIs und Schnittstellen für nahtlose Kommunikation.",
        },
        {
          title: "IT-Sicherheit",
          description: "Umfassende Sicherheitslösungen zum Schutz Ihrer digitalen Assets und Daten.",
        },
        {
          title: "Cloud-Lösungen",
          description: "Skalierbare und zuverlässige Cloud-Infrastrukturen für Ihr Unternehmen.",
        },
        {
          title: "Beratung",
          description: "Strategische Beratung zur Digitalisierung und Optimierung Ihrer Geschäftsprozesse.",
        },
        {
          title: "Gestaltung",
          description: "Firmenauftritt und digitale Gestaltung.",
        },
        {
          title: "Digitales Marketing",
          description: "Suchmaschinenoptimierung, soziale Netzwerke, Google Unternehmensprofil usw.",
        }

      ],
    },
    projects: {
      title: "Unsere Projekte",
      subtitle: "Erfolgsgeschichten unserer Kunden",
      items: [
        {
          title: "E-Commerce Plattform",
          description: "Entwicklung einer skalierbaren E-Commerce-Lösung mit individuellen Anforderungen.",
          tags: ["Webentwicklung", "API", "Cloud"],
          img: "/e-commerce.jpeg",
        },
        {
          title: "Mobile Banking App",
          description: "Sichere und benutzerfreundliche Banking-App mit modernster Verschlüsselungstechnologie.",
          tags: ["App-Entwicklung", "Sicherheit", "UX/UI"],
          img: "/mobile.jpeg",
        },
        {
          title: "IoT Dashboard",
          description: "Echtzeit-Dashboard zur Überwachung und Steuerung von IoT-Geräten.",
          tags: ["Webentwicklung", "IoT", "Echtzeit-Daten"],
          img: "/dash.jpeg",
        },
      ],
    },
    contact: {
      title: "Kontakt",
      subtitle: "Treten Sie mit uns in Kontakt – wir freuen uns auf Ihre Nachricht.",
      name: "Name",
      email: "E-Mail",
      message: "Nachricht",
      send: "Absenden",
      success: "Nachricht gesendet!",
      error: "Fehler beim Senden.",
    },
    footer: {
      imprint: "Impressum",
      imprintText: "Codig GmbH • Musterstraße 1 • 12345 Berlin • codigsol.com",
      copyright: "© 2023 Codig. Alle Rechte vorbehalten.",
    },
  },
  en: {
    navigation: {
      about: "About Us",
      services: "Services",
      projects: "Projects",
      contact: "Contact",
    },
    hero: {
      title: "Secure Your Digital Future",
      subtitle: "Expertise in cybersecurity, web/mobile development, and consulting to advance your business.",
      cta: "Learn more",
    },
    about: {
      title: "About Codig",
      subtitle: "We are your partner for digital solutions",
      content: [
        "Codig is an innovative technology company specializing in the development of customized digital solutions.",
        "Our team of experienced developers, designers, and consultants works closely with you to turn your vision into reality.",
        "With our expertise in web development, app development, IT security, and cloud solutions, we offer you a comprehensive service from a single source.",
      ],
      stats: [
        {
          value: "50+",
          label: "Satisfied Clients",
        },
        {
          value: "100+",
          label: "Completed Projects",
        },
        {
          value: "5+",
          label: "Years of Experience",
        },
        {
          value: "24/7",
          label: "Support",
        },
      ],
    },
    services: {
      title: "Our Services",
      subtitle: "Tailored solutions for your business",
      items: [
        {
          title: "Web Development",
          description: "Modern, responsive websites and web applications using the latest technologies.",
        },
        {
          title: "App Development",
          description: "Native and cross-platform apps for iOS and Android with optimal performance.",
        },
        {
          title: "APIs & Integrations",
          description: "Development and integration of APIs and interfaces for seamless communication.",
        },
        {
          title: "Cybersecurity",
          description: "Comprehensive security solutions to protect your digital assets and data.",
        },
        {
          title: "Cloud Solutions",
          description: "Scalable and reliable cloud infrastructures for your business.",
        },
        {
          title: "Consulting",
          description: "Strategic consulting for digitalization and optimization of your business processes.",
        },
        {
          title: "Design",
          description: "Corporate design & digital design.",
        },
        {
          title: "Digital Marketing",
          description: "Seo, social media marketing, Google my business etc.",
        },
      ],
    },
    projects: {
      title: "Our Projects",
      subtitle: "Success stories of our clients",
      items: [
        {
          title: "E-Commerce Platform",
          description: "Development of a scalable e-commerce solution with custom requirements.",
          tags: ["Web Development", "API", "Cloud"],
          img: "/e-commerce.jpeg",
        },
        {
          title: "Mobile Banking App",
          description: "Secure and user-friendly banking app with state-of-the-art encryption technology.",
          tags: ["App Development", "Security", "UX/UI"],
          img: "/mobile.jpeg",
        },
        {
          title: "IoT Dashboard",
          description: "Real-time dashboard for monitoring and controlling IoT devices.",
          tags: ["Web Development", "IoT", "Real-time Data"],
          img: "/dash.jpeg",
        },
      ],
    },
    contact: {
      title: "Contact",
      subtitle: "Get in touch with us – we look forward to hearing from you.",
      name: "Name",
      email: "Email",
      message: "Message",
      send: "Send",
      success: "Message sent!",
      error: "Error sending message.",
    },
    footer: {
      imprint: "Imprint",
      imprintText: "Codig GmbH • Musterstraße 1 • 12345 Berlin • codigsol.com",
      copyright: "© 2023 Codig. All rights reserved.",
    },
  },
}

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (section: keyof ContentType["de"], key: string) => string
  getServiceItems: () => Array<{ title: string; description: string }>
  getProjectItems: () => Array<{ title: string; description: string; tags: string[]; img:string }>
  getAboutContent: () => string[]
  getStats: () => Array<{ value: string; label: string }>
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({
  children,
  defaultLanguage = "de",
}: {
  children: ReactNode
  defaultLanguage?: Language
}) {
  const [language, setLanguage] = useState<Language>(defaultLanguage)

  const t = (section: keyof ContentType["de"], key: string) => {
    return content[language][section][key as keyof (typeof content)[typeof language][typeof section]]
  }

  const getServiceItems = () => {
    return content[language].services.items
  }

  const getProjectItems = () => {
    return content[language].projects.items
  }

  const getAboutContent = () => {
    return content[language].about.content
  }

  const getStats = () => {
    return content[language].about.stats
  }

  return (
    <LanguageContext.Provider
      value={{ language, setLanguage, t, getServiceItems, getProjectItems, getAboutContent, getStats }}
    >
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}