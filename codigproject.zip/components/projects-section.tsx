"use client"

import { useLanguage } from "./language-provider"
import Image from "next/image"
import AnimationWrapper from "./animation-wrapper"

export default function ProjectsSection() {
  const { t, getProjectItems } = useLanguage()
  const projects = getProjectItems()

  return (
    <section className="py-20 bg-[#121212]" id="projects">
      <div className="container mx-auto px-4">
        <AnimationWrapper>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white">{t("projects", "title")}</h2>
            <div className="w-20 h-1 bg-green-600 mx-auto mt-4"></div>
            <p className="text-gray-300 mt-4 max-w-2xl mx-auto">{t("projects", "subtitle")}</p>
          </div>
        </AnimationWrapper>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <AnimationWrapper key={index} direction="up" delay={index * 0.1} threshold={0.2}>
              <div className="bg-[#1a1a1a] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow border border-gray-800 h-full">
                <div className="relative h-48">
                  <Image
                    src={`${project.img}?height=300&width=500&text=Project+${index + 1}`}
                    alt={project.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-white">{project.title}</h3>
                  <p className="text-gray-300 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 bg-green-900/30 text-green-400 text-xs font-medium rounded-full border border-green-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </AnimationWrapper>
          ))}
        </div>
      </div>
    </section>
  )
}