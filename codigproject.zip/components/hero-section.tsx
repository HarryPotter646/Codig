"use client"
import AnimationWrapper from "./animation-wrapper"
import { useLanguage } from "./language-provider"
import AnimationRing from "./orbital-animation"

export default function HeroSection() {
  const { t } = useLanguage()

  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-32 relative" id="about">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <AnimationWrapper direction="right" duration={0.8}>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-white leading-tight">
                {t("hero", "title")}
              </h1>
            </AnimationWrapper>
            <AnimationWrapper direction="right" delay={0.2} duration={0.8}>
              <p className="text-lg text-gray-300 max-w-lg">{t("hero", "subtitle")}</p>
            </AnimationWrapper>
            <AnimationWrapper direction="up" delay={0.4} duration={0.8}>
              <div className="mt-8">
                <a
                  href="#about"
                  className="bg-green-600 hover:bg-green-700 text-black font-medium py-3 px-6 rounded-md transition-colors"
                >
                  {t("hero", "cta")}
                </a>
              </div>
            </AnimationWrapper>
          </div>
          <div className="md:w-1/2 flex justify-center md:justify-end">
            <AnimationWrapper direction="left" duration={0.8}>
              <AnimationRing />
              {/* <div className="relative w-full max-w-md">
                <div className="relative z-10">
                  
                  <Image
                    src="/placeholder.svg?height=400&width=500"
                    alt="Digital Solutions"
                    width={500}
                    height={400}
                    className="rounded-lg shadow-xl"
                  /> 
                </div>
                <div className="absolute -bottom-4 -right-4 w-full h-full border-2 border-green-600 rounded-lg z-0"></div>
              </div> */}
            </AnimationWrapper>
          </div>
        </div>
      </div>
    </section>
  )
}