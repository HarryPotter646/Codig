"use client"

import { useLanguage } from "./language-provider"

export default function Imprint() {
  const { t } = useLanguage()

  return <div className="max-w-md mx-auto p-4 bg-black/20 border border-gray-600 rounded-lg">{t("imprintText")}</div>
}
