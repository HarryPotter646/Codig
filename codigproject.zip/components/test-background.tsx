"use client"

export default function TestBackground() {
  return (
    <div className="fixed top-0 left-0 w-full h-full bg-red-500 opacity-30 z-0">
      TEST BACKGROUND
    </div>
  )
}