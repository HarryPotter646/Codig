"use client"

import { useState, useEffect } from "react"
import { useLanguage } from "./language-provider"
import { Menu } from 'lucide-react'
import AnimationWrapper from "./animation-wrapper"

export default function Navbar() {
  const { language, setLanguage, t } = useLanguage()
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-[#191919]/90 backdrop-blur-sm py-2 shadow-md" : "bg-transparent py-4"
      }`}
    >
        <div className="container mx-auto px-4">
        <div className="flex justify-between items center">
          <AnimationWrapper direction="right" duration={0.7}>
            <div className="flex items-center justify-start">
              <img src="/codig-logo.png" alt="Codig Logo" className="h-52 w-auto mr-8" />
            </div>
          </AnimationWrapper>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <AnimationWrapper direction="down" delay={0.1} duration={0.7}>
              <a
                href="#about"
                className="text-gray-300 hover:text-green-400 transition-colors font-medium"
              >
                {t("navigation", "about")}
              </a>
            </AnimationWrapper>
            <AnimationWrapper direction="down" delay={0.2} duration={0.7}>
              <a
                href="#services"
                className="text-gray-300 hover:text-green-400 transition-colors font-medium"
              >
                {t("navigation", "services")}
              </a>
            </AnimationWrapper>
            <AnimationWrapper direction="down" delay={0.3} duration={0.7}>
              <a
                href="#projects"
                className="text-gray-300 hover:text-green-400 transition-colors font-medium"
              >
                {t("navigation", "projects")}
              </a>
            </AnimationWrapper>
            <AnimationWrapper direction="down" delay={0.4} duration={0.7}>
              <a
                href="#contact"
                className="text-gray-300 hover:text-green-400 transition-colors font-medium"
              >
                {t("navigation", "contact")}
              </a>
            </AnimationWrapper>
            <AnimationWrapper direction="left" delay={0.5} duration={0.7}>
              <div className="flex space-x-2 ml-4">
                <button
                  onClick={() => setLanguage("de")}
                  className={`w-8 h-8 rounded-full overflow-hidden border-2 ${
                    language === "de" ? "border-green-400" : "border-transparent"
                  }`}
                  aria-label="Deutsch"
                >
                  <div className="w-full h-full bg-gray-800 flex items-center justify-center text-gray-300">DE</div>
                </button>
                <button
                  onClick={() => setLanguage("en")}
                  className={`w-8 h-8 rounded-full overflow-hidden border-2 ${
                    language === "en" ? "border-green-400" : "border-transparent"
                  }`}
                  aria-label="English"
                >
                  <div className="w-full h-full bg-gray-800 flex items-center justify-center text-gray-300">EN</div>
                </button>
              </div>
            </AnimationWrapper>
          </nav>

          {/* Mobile Menu Button */}
          <AnimationWrapper direction="left" duration={0.7}>
            <button
              className="md:hidden text-gray-300"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              <Menu size={24} />
            </button>
          </AnimationWrapper>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden pt-4 pb-2 flex flex-col space-y-4 border-t border-gray-700 mt-4">
            <a
              href="#about"
              className="text-gray-300 hover:text-green-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("navigation", "about")}
            </a>
            <a
              href="#services"
              className="text-gray-300 hover:text-green-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("navigation", "services")}
            </a>
            <a
              href="#projects"
              className="text-gray-300 hover:text-green-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("navigation", "projects")}
            </a>
            <a
              href="#contact"
              className="text-gray-300 hover:text-green-400 transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("navigation", "contact")}
            </a>
            <div className="flex space-x-2">
              <button
                onClick={() => setLanguage("de")}
                className={`w-8 h-8 rounded-full overflow-hidden border-2 ${
                  language === "de" ? "border-green-400" : "border-transparent"
                }`}
                aria-label="Deutsch"
              >
                <div className="w-full h-full bg-gray-800 flex items-center justify-center text-gray-300">DE</div>
              </button>
              <button
                onClick={() => setLanguage("en")}
                className={`w-8 h-8 rounded-full overflow-hidden border-2 ${
                  language === "en" ? "border-green-400" : "border-transparent"
                }`}
                aria-label="English"
              >
                <div className="w-full h-full bg-gray-800 flex items-center justify-center text-gray-300">EN</div>
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}