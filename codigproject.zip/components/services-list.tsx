"use client"

import { useLanguage } from "./language-provider"

export default function ServicesList() {
  const { getList } = useLanguage()
  const services = getList("serviceList")

  return (
    <ul className="max-w-md mx-auto space-y-2">
      {services.map((service, index) => (
        <li
          key={index}
          className="p-3 bg-black/20 border border-green-600/30 rounded-lg hover:bg-green-600/10 transition-colors"
        >
          {service}
        </li>
      ))}
    </ul>
  )
}
