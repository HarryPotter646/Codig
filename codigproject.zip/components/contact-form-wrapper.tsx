"use client"

import ContactForm from "./contact-form"

export default function ContactFormWrapper() {
  return <ContactForm />
}
