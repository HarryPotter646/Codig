'use client';

import React, { useRef, useEffect } from 'react';

export default function FlowingTextBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    console.log('FlowingTextBackground useEffect wird ausgeführt');

    const canvas = canvasRef.current;
    if (!canvas) {
      console.error('Canvas-Element nicht gefunden');
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      console.error('Canvas-Kontext konnte nicht erstellt werden');
      return;
    }

    console.log("Canvas initialisiert");

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      console.log(`Canvas resized: ${canvas.width}x${canvas.height}`);
    };

    resizeCanvas();

    const fontFamily =
      "'JetBrains Mono', 'Consolas', 'Monaco', 'Courier New', monospace";

    const techElements = [
      'JAVA', 'PYTHON', 'JAVASCRIPT', 'HTML5', 'CSS3', 'PHP', 'REACT', 'ANGULAR', 'VUE',
      'AES256', 'RSA', 'SHA256', 'HTTPS', 'FIREWALL', 'VPN', 'DDOS', 'ENCRYPTION',
      'AWS', 'AZURE', 'GCP', 'DOCKER', 'KUBERNETES', 'SERVERLESS', 'API', 'MICROSERVICES',
      'CHATGPT', 'LLAMA', 'BERT', 'TENSORFLOW', 'PYTORCH', 'BIGDATA', 'ML', 'AI',
      '{}', '[]', '</>', '#!/', '0101', 'sudo', 'npm', 'git', '://', '&&', '||', '==', '===',
      'WINDOWS', 'APPLE', 'LINUX', 'CISCO', 'META', 'GOOGLE', 'AMAZON', 'MICROSOFT',
      'function()', 'if()', 'for()', 'while()', 'return', 'import', 'export', 'class', 'const', 'let', 'var',
      '=>', 'async', 'await', 'try{}', 'catch{}', 'finally{}', '.then()', '.catch()', 'Promise<>',
      'interface', 'type', 'enum', 'namespace', 'public', 'private', 'protected', 'static',
      'SELECT * FROM', 'INSERT INTO', 'UPDATE', 'DELETE FROM', 'WHERE', 'JOIN', 'GROUP BY',
      'GET /api', 'POST /api', 'PUT /api', 'DELETE /api', '200 OK', '404 NOT FOUND', '500 ERROR',
    ];

    class Particle {
      x: number;
      y: number;
      text: string;
      speed: number;
      size: number;
      direction: number;
      opacity: number;
      color: string;

      constructor(x: number, y: number, text: string, direction: number) {
        this.x = x;
        this.y = y;
        this.text = text;
        this.speed = Math.random() * 0.3 + 0.1;
        this.size = Math.floor(Math.random() * 6) + 12;
        this.direction = direction;
        this.opacity = Math.random() * 0.4 + 0.2;

        const colors = [
          'rgba(0, 200, 0, ',
          'rgba(86, 156, 214, ',
          'rgba(220, 220, 170, ',
          'rgba(156, 220, 254, ',
          'rgba(206, 145, 120, ',
          'rgba(181, 206, 168, ',
        ];

        const colorIndex = Math.random() < 0.6 ? 0 : Math.floor(Math.random() * colors.length);
        this.color = colors[colorIndex] + this.opacity + ')';
      }

      draw(ctx: CanvasRenderingContext2D) {
        ctx.font = `${this.size}px ${fontFamily}`;
        ctx.fillStyle = this.color;
        ctx.fillText(this.text, this.x, this.y);
      }

      update(canvasWidth: number, canvasHeight: number) {
        this.x += this.speed * this.direction;

        if (this.direction > 0 && this.x > canvasWidth + 50) {
          this.x = -50;
          this.y = Math.random() * canvasHeight;
        } else if (this.direction < 0 && this.x < -50) {
          this.x = canvasWidth + 50;
          this.y = Math.random() * canvasHeight;
        }

        this.y = Math.min(Math.max(this.y, 50), canvasHeight - 50);
      }
    }

    const particles: Particle[] = [];

    const initParticles = () => {
      particles.length = 0;
      const particleCount = 250;
      for (let i = 0; i < particleCount; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const textIndex = Math.floor(Math.random() * techElements.length);
        const direction = Math.random() > 0.5 ? 1 : -1;
        particles.push(new Particle(x, y, techElements[textIndex], direction));
      }
      console.log(`${particles.length} particles initialized`);
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.update(canvas.width, canvas.height);
        p.draw(ctx);
      });
      requestAnimationFrame(animate);
    };

    const handleResize = () => {
      resizeCanvas();
      initParticles();
    };

    window.addEventListener('resize', handleResize);

    initParticles();
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full z-0 opacity-40"
    />
  );
}
