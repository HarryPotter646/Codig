"use client"

import type React from "react"

import { useState } from "react"
import { useLanguage } from "./language-provider"

export default function ContactForm() {
  const { t } = useLanguage()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus("submitting")

    // Simulate form submission
    setTimeout(() => {
      if (formData.name && formData.email && formData.message) {
        setStatus("success")
        setFormData({ name: "", email: "", message: "" })
      } else {
        setStatus("error")
      }

      // Reset status after 3 seconds
      setTimeout(() => setStatus("idle"), 3000)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto bg-[#1a1a1a] p-6 rounded-lg shadow-md border border-gray-800">
      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-left mb-1 text-gray-300 font-medium">
            {t("contact", "name")}
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            disabled={status === "submitting"}
            className="w-full p-3 bg-[#252525] border border-gray-700 rounded-md focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 text-white"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-left mb-1 text-gray-300 font-medium">
            {t("contact", "email")}
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            disabled={status === "submitting"}
            className="w-full p-3 bg-[#252525] border border-gray-700 rounded-md focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 text-white"
          />
        </div>

        <div>
          <label htmlFor="message" className="block text-left mb-1 text-gray-300 font-medium">
            {t("contact", "message")}
          </label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            disabled={status === "submitting"}
            rows={4}
            className="w-full p-3 bg-[#252525] border border-gray-700 rounded-md focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500 text-white"
          />
        </div>

        <button
          type="submit"
          disabled={status === "submitting"}
          className="w-full py-3 px-4 bg-green-600 hover:bg-green-700 text-white font-medium rounded-md transition-colors disabled:opacity-70"
        >
          {status === "submitting" ? "..." : t("contact", "send")}
        </button>

        {status === "success" && (
          <div className="p-3 bg-green-900/30 border border-green-800 rounded-md text-green-400">
            {t("contact", "success")}
          </div>
        )}

        {status === "error" && (
          <div className="p-3 bg-red-900/30 border border-red-800 rounded-md text-red-400">{t("contact", "error")}</div>
        )}
      </div>
    </form>
  )
}