"use client"

export default function PartnersSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
          {/* Partner logos */}
          <div className="w-24 h-12 flex items-center justify-center">
            <img src="/partner1.png" alt="Partner 1 Logo" className="partner-logo" />
          </div>
          <div className="w-24 h-12 flex items-center justify-center">
            <img src="/partner2.png" alt="Partner 2 Logo" className="partner-logo" />
          </div>
          <div className="w-24 h-12 flex items-center justify-center">
            <img src="/partner3.png" alt="Partner 3 Logo" className="partner-logo" />
          </div>
          <div className="w-24 h-12 flex items-center justify-center">
            <img src="/partner4.png" alt="Partner 4 Logo" className="partner-logo" />
          </div>
        </div>
      </div>

      {/* Kurven-Form */}
      <div className="relative h-24 overflow-hidden">
        <svg
          viewBox="0 0 1440 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="absolute bottom-0 w-full h-full"
        >
          <path
            d="M0 0L48 5.3C96 10.7 192 21.3 288 26.7C384 32 480 32 576 26.7C672 21.3 768 10.7 864 10.7C960 10.7 1056 21.3 1152 26.7C1248 32 1344 32 1392 32H1440V100H1392C1344 100 1248 100 1152 100C1056 100 960 100 864 100C768 100 672 100 576 100C480 100 384 100 288 100C192 100 96 100 48 100H0V0Z"
            fill="#f0f0f0"
          />
        </svg>
      </div>
    </section>
  )
}
